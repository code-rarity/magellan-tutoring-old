<?php

namespace Drupal\metatag\Plugin\Field;

use Drupal\Core\Field\FieldItemList;

/**
 * Defines a metatag list class for better normalization targeting.
 */
class MetatagEntityFieldItemList extends FieldItemList {
}
