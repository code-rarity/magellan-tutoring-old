8.x-1.0-alpha1
Add weight to display_id field
Remove preconfigured options that attaches views reference behaviour
to entity types
Change widget name to viewsreference_autocomplete
Supply display_id defaults properly on edit

8.x-1.0-alpha2
Add Views argument

8.x-1.0-alpha3
Modify widget so it works in nested environments such as inside Paragraphs

8.x-1.0-alpha4
Add views block title option
Add check in update for table exists

8.x-1.0-alpha5
Add install script for title field

8.x-1.0-alpha6
Add select widget
Add composer.json
Add user access check

8.x-1.0-alpha7
Revert access check - not working
Add select widget

8.x-1.0-alpha8
Change to views_embed_view function
Add view plugin select to limit plugins available in field
Attempt to fix composer problem

8.x-1.0-beta1
Fix argument handling: https://www.drupal.org/node/2847192
Add multiple arguments: https://www.drupal.org/node/2846625
Fix placeholder error: https://www.drupal.org/node/2838413
Remove redundant code
Remove extra settings: https://www.drupal.org/node/2851184
Add preexecute: https://www.drupal.org/node/2851058

8.x-1.0-beta2
More fixes to arguments: https://www.drupal.org/node/2888158
Clean up install code: https://www.drupal.org/node/2862022

8.x-1.0-rc1
Apply Details form type to title and argument options to prepare
for advanced options module
Run codesniffer on code
Fixes to views plugin filter: https://www.drupal.org/node/2857697
Add error message for when no plugin available in a view
Add Empty validation on display_id value

8.x-1.0-rc2
Fix incorrectly applied patch at https://www.drupal.org/node/2857697

8.x-1.0-rc3
Coding standards applied

8.x-1.0
Title theme suggestions: https://www.drupal.org/node/2901356

8.x-1.1
Remove cache setting: https://www.drupal.org/node/2912148
Attachment areas fix: https://www.drupal.org/node/2910824
Remove view build step: https://www.drupal.org/project/viewsreference/issues/2923740
Fix #states visibility: https://www.drupal.org/project/viewsreference/issues/2897999

8.x-1.3
JS translation: https://www.drupal.org/project/viewsreference/issues/2979298
Check for null view in trait: https://www.drupal.org/project/viewsreference/issues/2953761
Translate none option: https://www.drupal.org/project/viewsreference/issues/2958796
Argument cache: https://www.drupal.org/project/viewsreference/issues/3003900

8.x-1.4
Remove travis scripts
