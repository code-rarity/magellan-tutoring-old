<?php

namespace Drupal\uc_order;

/**
 * Defines a base editable order pane plugin implementation.
 */
abstract class EditableOrderPanePluginBase extends OrderPanePluginBase implements EditableOrderPanePluginInterface {

}
