/* Source and licensing information for the line(s) below can be found at http://www.magellantutoring.com/core/assets/vendor/jquery.ui/ui/tabbable-min.js. */
/*! jQuery UI - v1.12.1 - 2017-03-31
* http://jqueryui.com
* Copyright jQuery Foundation and other contributors; Licensed  */
!function(a){"function"==typeof define&&define.amd?define(["jquery","./version","./focusable"],a):a(jQuery)}(function(a){return a.extend(a.expr[":"],{tabbable:function(b){var c=a.attr(b,"tabindex"),d=null!=c;return(!d||c>=0)&&a.ui.focusable(b,d)}})});
/* Source and licensing information for the above line(s) can be found at http://www.magellantutoring.com/core/assets/vendor/jquery.ui/ui/tabbable-min.js. */